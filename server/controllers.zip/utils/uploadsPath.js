const path = require("path");
const fs = require("fs");

const SERVER_DIR = path.join(__dirname, "..");
const PARENT_DIR = path.join(SERVER_DIR, "..");

/**
 * Outer Hostinger uploads (sibling of nodejs/public_html), then inner fallback.
 * Prefer @uploads if present, else uploads (production screenshot).
 * Never create the inner server/uploads folder when outer is available.
 */
function getUploadsRoot() {
  const outerAt = path.join(PARENT_DIR, "@uploads");
  const outerUploads = path.join(PARENT_DIR, "uploads");
  const innerUploads = path.join(SERVER_DIR, "uploads");

  const candidates = [outerAt, outerUploads, innerUploads];
  for (const candidate of candidates) {
    try {
      if (fs.existsSync(candidate) && fs.statSync(candidate).isDirectory()) {
        return candidate;
      }
    } catch (_) {
      /* ignore */
    }
  }

  // Create outer uploads (not inner) so Hostinger redeploys do not wipe files
  fs.mkdirSync(outerUploads, { recursive: true });
  return outerUploads;
}

function listUploadRoots() {
  const roots = [
    getUploadsRoot(),
    path.join(PARENT_DIR, "@uploads"),
    path.join(PARENT_DIR, "uploads"),
    path.join(SERVER_DIR, "uploads"),
    path.join(PARENT_DIR, "Uploades"),
  ];
  return [...new Set(roots.map((p) => path.resolve(p)))];
}

function normalizeUploadRelative(filePath) {
  if (!filePath) return "";
  return String(filePath)
    .replace(/\\/g, "/")
    .replace(/^\/+/, "")
    .replace(/^Uploades\//i, "uploads/")
    .replace(/^@uploads\//i, "uploads/")
    // Canonical public path for new files is employeeDocuments; keep legacy lowercase readable
    .replace(
      /uploads\/employeedocuments\/employeedocuments\//gi,
      "uploads/employeeDocuments/"
    )
    .replace(
      /uploads\/employeeDocuments\/employeeDocuments\//gi,
      "uploads/employeeDocuments/"
    );
}

/**
 * Try several on-disk locations for a stored filePath.
 * Returns absolute path if found, otherwise null.
 */
function resolveUploadDiskPath(filePath) {
  if (!filePath) return null;

  const relative = normalizeUploadRelative(filePath);
  const basename = path.basename(relative);
  const uniqueRoots = listUploadRoots();
  const candidates = [];

  for (const root of uniqueRoots) {
    const underUploads = relative
      .replace(/^uploads\//i, "")
      .replace(/^@uploads\//i, "");
    candidates.push(path.join(root, underUploads));
    candidates.push(path.join(root, relative));

    // Both casings for employee document folders
    const underEmpDocs = underUploads
      .replace(/^employeedocuments\//i, "")
      .replace(/^employeeDocuments\//, "");
    candidates.push(path.join(root, "employeeDocuments", underEmpDocs));
    candidates.push(path.join(root, "employeedocuments", underEmpDocs));
    candidates.push(path.join(root, "employeeDocuments", basename));
    candidates.push(path.join(root, "employeedocuments", basename));
  }

  for (const candidate of candidates) {
    try {
      if (candidate && fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
        return candidate;
      }
    } catch (_) {
      /* ignore */
    }
  }
  return null;
}

/**
 * Ensure a subdirectory under the uploads root exists; return absolute path.
 */
function ensureUploadSubdir(...parts) {
  const dir = path.join(getUploadsRoot(), ...parts);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

module.exports = {
  getUploadsRoot,
  listUploadRoots,
  normalizeUploadRelative,
  resolveUploadDiskPath,
  ensureUploadSubdir,
  SERVER_DIR,
};
