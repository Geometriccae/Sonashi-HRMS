/**
 * Official holidays 2026 (from OFFICIAL HOLIDAYS IN 2026 list).
 * Dates in YYYY-MM-DD for date picker disabled list and comparisons.
 */
export const OFFICIAL_HOLIDAYS_2026 = [
  '2026-01-01', // New Year's Day
  '2026-01-26', // Republic Day
  '2026-02-19', // Chhatrapati Shivaji Maharaj Jayanti
  '2026-03-03', // HOLI
  '2026-03-19', // GUDI PADWA
  '2026-03-21', // RAMZAN ID
  '2026-03-26', // RAM NAVMI
  '2026-03-31', // MAHAVIR JAYANTI
  '2026-04-03', // GOOD FRIDAY
  '2026-04-14', // DR. BABASAHEB AMBEDKAR JAYANTI
  '2026-05-01', // MAHARASHTRA DAY
  '2026-06-26', // MUHARRAM - BAKRI-EID
  '2026-08-15', // INDEPENDENCE DAY / PARSI NEW YEAR
  '2026-08-26', // EID -A MILAD
  '2026-08-28', // RAKSHA BANDHAN
  '2026-09-14', // GANESH CHATURTI
  '2026-10-02', // MAHATMA GANDHI JAYANTI
  '2026-10-20', // DASARA
  '2026-11-06', // DIWALI- LAXMI PUJAN
  '2026-11-10', // DIWALI- PADVA
  '2026-11-11', // DIWALI- BHAUBIJ
  '2026-11-24', // GURU NANAK JAYANTI
  '2026-12-25', // CHRISTMAS
];
