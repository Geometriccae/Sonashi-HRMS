/**
 * Payable working days for a salary period.
 * Calendar days are used only to count payable/present days.
 *
 * Earnings are never prorated: Basic Pay and the allowances are paid at the
 * exact values held in Employee Master. Unpaid days are charged as a separate
 * deduction on a fixed 30-day month:
 *   Daily Salary = Monthly Salary / 30
 *   Unpaid Days = 30 - Payable Days (never below zero)
 *   Leave Deduction = Daily Salary × Unpaid Days
 *   Net Payable = Gross Salary - (Leave Deduction + other deductions)
 */

import { lastWorkingDayIsEmploymentExit } from "./employeeStatusDisplay";

export const PAYROLL_MONTH_DAYS = 30;

export const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const APPROVED_LEAVE_STATUSES = new Set(["Approved", "HOD Approved"]);

export const toDayStart = (value) => {
  if (!value) return null;
  if (typeof value === "string") {
    const match = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (match) {
      return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    }
  }
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return null;
  return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
};

export const dateKey = (value) => {
  const d = toDayStart(value);
  if (!d) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

const laterDay = (a, b) => (!a ? b : !b ? a : a > b ? a : b);
const earlierDay = (a, b) => (!a ? b : !b ? a : a < b ? a : b);

const normalizeName = (name) =>
  String(name || "").toLowerCase().replace(/[\s_.-]+/g, "").trim();

const leaveMatchesEmployee = (leave, employee) => {
  if (!leave || !employee) return false;
  const empMongo = String(employee._id || "");
  const empCode = String(employee.employeeId || "");
  const empName = normalizeName(employee.employeeName);

  const populated = leave.employee;
  if (populated) {
    if (String(populated) === empMongo) return true;
    if (typeof populated === "object") {
      if (populated._id && String(populated._id) === empMongo) return true;
      const linkedEmp = populated.employeeId?._id || populated.employeeId || null;
      if (linkedEmp && String(linkedEmp) === empMongo) return true;
    }
  }

  if (leave.employeeId && (String(leave.employeeId) === empCode || String(leave.employeeId) === empMongo)) {
    return true;
  }
  const leaveName = normalizeName(leave.employeeName || "");
  return Boolean(empName && leaveName && leaveName === empName);
};

const isHalfDayLeave = (leave) => {
  const text = `${leave?.leaveType || ""} ${leave?.reason || ""} ${leave?.changeRemarks || ""}`;
  return /half[\s-]?day/i.test(text);
};

const isUnpaidLeaveType = (leave) => {
  const text = `${leave?.leaveType || ""} ${leave?.reason || ""} ${leave?.changeRemarks || ""}`;
  return /\b(lwp|unpaid|without\s*pay)\b/i.test(text);
};

const unpaidFractionForLeave = (leave) => {
  if (isHalfDayLeave(leave)) return 0.5;
  if (isUnpaidLeaveType(leave)) return 1;
  return 1;
};

export const getMonthIndex = (monthValue) => {
  const n = Number(monthValue);
  if (Number.isFinite(n) && n >= 1 && n <= 12) return n - 1;
  const normalized = String(monthValue || "").trim().toLowerCase();
  return MONTH_NAMES.findIndex((name) => name.toLowerCase() === normalized);
};

export const getPayrollPeriod = (monthValue, yearValue) => {
  const monthIndex = getMonthIndex(monthValue);
  const year = Number(yearValue);
  if (monthIndex < 0 || !Number.isFinite(year)) return null;
  const start = new Date(year, monthIndex, 1);
  const end = new Date(year, monthIndex + 1, 0);
  return {
    monthIndex,
    year,
    start,
    end,
    totalCalendarDays: end.getDate(),
  };
};

const getPayrollExitDate = (employee) => {
  if (!lastWorkingDayIsEmploymentExit(employee?.employeeStatus)) return null;
  return toDayStart(employee?.lastWorkingDay) || toDayStart(employee?.noticePeriodEndDate);
};

const getEmploymentWindow = (employee, monthStart, monthEnd) => {
  const join = toDayStart(employee?.doj);
  const last = getPayrollExitDate(employee);
  if (join && join > monthEnd) return null;
  if (last && last < monthStart) return null;
  const start = laterDay(monthStart, join);
  const end = earlierDay(monthEnd, last);
  if (!start || !end || end < start) return null;
  return { start, end };
};

const attendanceEmployeeId = (record) =>
  String(record?.employee?._id || record?.employee || "");

export const computePayablePayrollDays = ({
  employee,
  month,
  year,
  attendanceRecords = [],
  leaveRequests = [],
} = {}) => {
  const period = getPayrollPeriod(month, year);
  if (!period) {
    return {
      totalWorkingDays: 0,
      presentDays: 0,
      payableDays: 0,
      skip: true,
      skipReason: "Invalid payroll month",
    };
  }

  const totalWorkingDays = period.totalCalendarDays;
  const window = getEmploymentWindow(employee, period.start, period.end);
  if (!window) {
    return {
      totalWorkingDays,
      presentDays: 0,
      payableDays: 0,
      skip: true,
      skipReason: "Not employed during this month",
    };
  }

  const empId = String(employee._id || "");
  const attendanceByDay = {};
  (attendanceRecords || []).forEach((record) => {
    if (attendanceEmployeeId(record) !== empId) return;
    const key = dateKey(record.date);
    if (key) attendanceByDay[key] = record.status;
  });

  const unpaidByDay = {};
  (leaveRequests || []).forEach((leave) => {
    if (!APPROVED_LEAVE_STATUSES.has(leave?.status)) return;
    if (!leaveMatchesEmployee(leave, employee)) return;
    const start = laterDay(window.start, toDayStart(leave.startDate));
    const end = earlierDay(window.end, toDayStart(leave.endDate));
    if (!start || !end || end < start) return;
    const fraction = unpaidFractionForLeave(leave);
    const cursor = new Date(start);
    while (cursor <= end) {
      const key = dateKey(cursor);
      unpaidByDay[key] = Math.max(unpaidByDay[key] || 0, fraction);
      cursor.setDate(cursor.getDate() + 1);
    }
  });

  let payableDays = 0;
  let presentDays = 0;
  const cursor = new Date(window.start);
  while (cursor <= window.end) {
    const key = dateKey(cursor);
    const att = attendanceByDay[key];
    let unpaid = unpaidByDay[key] || 0;
    if (att === "Leave") unpaid = Math.max(unpaid, 1);
    const payable = Math.max(0, 1 - unpaid);
    payableDays += payable;
    if (att === "Onsite") presentDays += payable;
    else if (!att && payable > 0) presentDays += payable;
    cursor.setDate(cursor.getDate() + 1);
  }

  payableDays = Math.round(payableDays * 100) / 100;
  presentDays = Math.round(presentDays * 100) / 100;

  if (payableDays <= 0) {
    return {
      totalWorkingDays,
      presentDays: 0,
      payableDays: 0,
      skip: true,
      skipReason: "No payable working days",
    };
  }

  return {
    totalWorkingDays,
    presentDays: Math.min(presentDays, totalWorkingDays),
    payableDays: Math.min(payableDays, totalWorkingDays),
    skip: false,
    skipReason: "",
  };
};

export const scaleSalaryAmount = (amount, payableDays) => {
  const base = Number(amount);
  const payable = Number(payableDays);
  if (!Number.isFinite(base) || base === 0) return 0;
  if (!Number.isFinite(payable) || payable <= 0) return 0;
  return Math.round(((base * payable) / PAYROLL_MONTH_DAYS) * 100) / 100;
};

/** Days of the 30-day payroll month that the employee is not paid for. */
export const unpaidPayrollDays = (payableDays) => {
  const payable = Number(payableDays);
  if (!Number.isFinite(payable) || payable < 0) return 0;
  return Math.max(0, PAYROLL_MONTH_DAYS - payable);
};

/**
 * Leave / absence deduction for the unpaid part of a payroll month.
 * Earnings stay at their Employee Master values; this is what reduces net pay.
 */
export const leaveDeductionAmount = (monthlyGross, payableDays) =>
  scaleSalaryAmount(monthlyGross, unpaidPayrollDays(payableDays));
