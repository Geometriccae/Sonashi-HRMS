import config, { getApiBaseUrl } from '../config/config';

const CACHE_TTL_MS = 180000; // 3 minutes — invalidate on writes

class EmployeeService {
  constructor() {
    const raw = (config.API_BASE_URL || '').trim();
    let apiRoot;
    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      apiRoot = raw.replace(/\/$/, '');
      if (!apiRoot.endsWith('/api')) {
        apiRoot = apiRoot.endsWith('/') ? `${apiRoot}api` : `${apiRoot}/api`;
      }
    } else {
      const host = getApiBaseUrl();
      apiRoot = host ? `${host.replace(/\/$/, '')}/api` : '/api';
    }

    this.baseURL = `${apiRoot}/employees`;
    this.attendanceURL = `${apiRoot}/attendance`;
    this._cache = { list: null, listWithVacation: null, vacationBundle: null, full: null, metrics: null, stats: null, statsBasic: null, filterOptions: null, filterOptionsTs: 0, ts: 0 };
    this._inflight = {};
  }

  _isCacheValid() {
    return this._cache.ts && (Date.now() - this._cache.ts) < CACHE_TTL_MS;
  }

  invalidateCache() {
    this._cache = { list: null, listWithVacation: null, vacationBundle: null, full: null, metrics: null, stats: null, statsBasic: null, filterOptions: null, filterOptionsTs: 0, ts: 0 };
    this._inflight = {};
    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('hrms:employee-data-changed', { detail: { ts: Date.now() } }));
    }
  }

  onEmployeeDataChanged(handler) {
    if (typeof window === 'undefined' || typeof handler !== 'function') return () => {};
    const wrapped = () => handler();
    window.addEventListener('hrms:employee-data-changed', wrapped);
    return () => window.removeEventListener('hrms:employee-data-changed', wrapped);
  }

  // Get auth token from localStorage
  getAuthToken() {
    return localStorage.getItem('token');
  }

  // Get auth headers
  getAuthHeaders() {
    const token = this.getAuthToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };
  }

  // Lightweight list for tables, dashboards, dropdowns
  // includeVacation: merge live vacation status (slower; only for vacation UIs)
  async getEmployeesList({ force = false, includeVacation = false } = {}) {
    const cacheKey = includeVacation ? 'listWithVacation' : 'list';
    if (!force && this._isCacheValid() && this._cache[cacheKey]) {
      return this._cache[cacheKey];
    }
    const inflightKey = `list:${includeVacation ? '1' : '0'}`;
    if (this._inflight[inflightKey]) {
      return this._inflight[inflightKey];
    }
    this._inflight[inflightKey] = (async () => {
      try {
        const params = new URLSearchParams({ view: 'list' });
        if (includeVacation) params.set('includeVacation', '1');
        const response = await fetch(`${this.baseURL}?${params}`, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        this._cache[cacheKey] = data;
        this._cache.ts = Date.now();
        return data;
      } catch (error) {
        console.error('Error fetching employee list:', error);
        throw error;
      } finally {
        delete this._inflight[inflightKey];
      }
    })();
    return this._inflight[inflightKey];
  }

  /**
   * Single round-trip for Dashboard / Annual Vacations:
   * employees with live vacation status + approved leave rows for yet-to-go.
   */
  async getVacationBundle({ force = false } = {}) {
    if (!force && this._isCacheValid() && this._cache.vacationBundle) {
      return this._cache.vacationBundle;
    }
    const inflightKey = 'vacationBundle';
    if (this._inflight[inflightKey]) {
      return this._inflight[inflightKey];
    }
    this._inflight[inflightKey] = (async () => {
      try {
        const params = new URLSearchParams({
          view: 'list',
          includeVacation: '1',
          withLeaves: '1',
        });
        const response = await fetch(`${this.baseURL}?${params}`, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const bundle = {
          employees: Array.isArray(data?.employees) ? data.employees : (Array.isArray(data) ? data : []),
          leaves: Array.isArray(data?.leaves) ? data.leaves : [],
        };
        this._cache.vacationBundle = bundle;
        this._cache.listWithVacation = bundle.employees;
        this._cache.ts = Date.now();
        return bundle;
      } catch (error) {
        console.error('Error fetching vacation bundle:', error);
        throw error;
      } finally {
        delete this._inflight[inflightKey];
      }
    })();
    return this._inflight[inflightKey];
  }

  // Server-side paginated list for the team members table
  async getEmployeesListPaginated({ page = 1, limit = 20, search = '', status = '', filters = {}, includeVacation = false } = {}) {
    try {
      const params = new URLSearchParams({ view: 'list', page: String(page), limit: String(limit) });
      if (search) params.set('search', search);
      if (status) params.set('status', status);
      if (includeVacation) params.set('includeVacation', '1');
      ['employeeName', 'dojFrom', 'dojTo', 'companyCode', 'employeeStatus'].forEach((key) => {
        const value = filters?.[key];
        if (value !== undefined && value !== null && String(value).trim()) {
          params.set(key, String(value).trim());
        }
      });
      const response = await fetch(`${this.baseURL}?${params}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      // Handle both paginated response { employees, total } and legacy flat array
      if (Array.isArray(data)) {
        return { employees: data, total: data.length, page, limit, totalPages: Math.ceil(data.length / limit) };
      }
      return data;
    } catch (error) {
      console.error('Error fetching paginated employee list:', error);
      throw error;
    }
  }

  async getEmployeeFilterOptions({ force = false } = {}) {
    if (!force && this._cache.filterOptions &&
      Date.now() - Number(this._cache.filterOptionsTs || 0) < CACHE_TTL_MS) {
      return this._cache.filterOptions;
    }
    if (!force && this._inflight.filterOptions) return this._inflight.filterOptions;
    this._inflight.filterOptions = (async () => {
      try {
        const response = await fetch(`${this.baseURL}/filter-options`, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        this._cache.filterOptions = data;
        this._cache.filterOptionsTs = Date.now();
        return data;
      } finally {
        delete this._inflight.filterOptions;
      }
    })();
    return this._inflight.filterOptions;
  }

  // Stats only — counts for dashboard / annual vacation cards
  // basic: true → headcount only (Team Management) — skips vacation/leave aggregates
  async getEmployeeStats({ force = false, basic = false } = {}) {
    const cacheSlot = basic ? 'statsBasic' : 'stats';
    if (!force && this._isCacheValid() && this._cache[cacheSlot]) {
      return this._cache[cacheSlot];
    }
    if (!force && this._inflight[cacheSlot]) {
      return this._inflight[cacheSlot];
    }
    this._inflight[cacheSlot] = (async () => {
      try {
        const params = new URLSearchParams();
        if (force) params.set('force', '1');
        if (basic) params.set('basic', '1');
        const qs = params.toString();
        const response = await fetch(`${this.baseURL}/stats${qs ? `?${qs}` : ''}`, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        this._cache[cacheSlot] = data;
        this._cache.ts = Date.now();
        return data;
      } catch (error) {
        console.error('Error fetching employee stats:', error);
        throw error;
      } finally {
        delete this._inflight[cacheSlot];
      }
    })();
    return this._inflight[cacheSlot];
  }

  /**
   * Annual Vacations: one tab page only (server-side pagination + filters).
   * tab: onVacation | yetToGo | returned
   */
  async getVacationTab({
    tab,
    page = 1,
    limit = 20,
    search = '',
    filters = {},
    all = false,
  } = {}) {
    try {
      const params = new URLSearchParams({
        tab: String(tab || ''),
        page: String(page),
        limit: String(all ? 100000 : limit),
      });
      if (all) params.set('all', '1');
      if (search) params.set('search', search);
      const f = filters || {};
      ['department', 'role', 'office', 'country', 'dojFrom', 'dojTo', 'expMin', 'expMax', 'vacationMonth', 'vacationYear']
        .forEach((key) => {
          if (f[key] !== undefined && f[key] !== null && f[key] !== '') {
            params.set(key, String(f[key]));
          }
        });
      const response = await fetch(`${this.baseURL}/vacation-tab?${params}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const tabData = await response.json();
      return tabData;
    } catch (error) {
      console.error('Error fetching vacation tab:', error);
      throw error;
    }
  }

  /**
   * Dashboard drill-down: fetch only the opened category (paginated).
   * category: total | active | inactive | onVacation | yetToGo | returned | visaExpiry | passportExpiry
   */
  async getDashboardCategory({ category, page = 1, limit = 50, search = '', all = false } = {}) {
    try {
      const params = new URLSearchParams({
        category: String(category || ''),
        page: String(page),
        limit: String(all ? 100000 : limit),
      });
      if (all) params.set('all', '1');
      if (search) params.set('search', search);
      const response = await fetch(`${this.baseURL}/dashboard-category?${params}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching dashboard category:', error);
      throw error;
    }
  }

  /**
   * HR Metrics payload — full enough for KPIs/charts, without profile photos.
   * Prefer this over getEmployees({ force: true }) on the metrics dashboard.
   */
  async getEmployeesForMetrics({ force = false } = {}) {
    if (!force && this._isCacheValid() && this._cache.metrics) {
      return this._cache.metrics;
    }
    if (!force && this._inflight.metrics) {
      return this._inflight.metrics;
    }
    this._inflight.metrics = (async () => {
      try {
        const response = await fetch(`${this.baseURL}?${new URLSearchParams({ view: 'metrics' })}`, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        this._cache.metrics = data;
        this._cache.ts = Date.now();
        return data;
      } catch (error) {
        console.error('Error fetching employees for metrics:', error);
        throw error;
      } finally {
        delete this._inflight.metrics;
      }
    })();
    return this._inflight.metrics;
  }

  // Get all employees (full records — use only when editing/detail views need everything)
  // Optional status: 'Active' | 'InActive' — applied server-side via ?status=
  async getEmployees({ force = false, status } = {}) {
    const statusFilter = status === 'Active' || status === 'InActive' ? status : '';
    // Never serve cached full list when a status filter is requested
    if (!force && !statusFilter && this._isCacheValid() && this._cache.full) {
      return this._cache.full;
    }
    const inflightKey = statusFilter ? `full:${statusFilter}` : 'full';
    if (!force && this._inflight[inflightKey]) {
      return this._inflight[inflightKey];
    }
    this._inflight[inflightKey] = (async () => {
      try {
        const url = statusFilter
          ? `${this.baseURL}?${new URLSearchParams({ status: statusFilter })}`
          : this.baseURL;
        const response = await fetch(url, {
          method: 'GET',
          headers: this.getAuthHeaders(),
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        if (!statusFilter) {
          this._cache.full = data;
          this._cache.ts = Date.now();
        }
        return data;
      } catch (error) {
        console.error('Error fetching employees:', error);
        throw error;
      } finally {
        delete this._inflight[inflightKey];
      }
    })();
    return this._inflight[inflightKey];
  }

  // Batch fetch profile photos for a list of employee IDs (current page only).
  async getProfilePhotosByIds(ids = []) {
    try {
      const clean = (ids || []).map((id) => String(id)).filter(Boolean);
      if (!clean.length) return [];
      const params = new URLSearchParams({ ids: clean.join(',') });
      const response = await fetch(`${this.baseURL}/photos?${params}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) return [];
      return await response.json();
    } catch (error) {
      console.error('Error fetching profile photos:', error);
      return [];
    }
  }

  // Get profile photo URL by employee email (for salary slip; auth: admin or same user)
  async getProfilePhotoByEmail(email) {
    try {
      if (!email || !String(email).trim()) return { profilePhoto: '' };
      const params = new URLSearchParams({ email: String(email).trim() });
      const response = await fetch(`${this.baseURL}/profile-photo?${params}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) return { profilePhoto: '' };
      return await response.json();
    } catch (error) {
      return { profilePhoto: '' };
    }
  }

  // Get single employee by ID
  async getEmployee(id) {
    try {
      console.log('get one employee', this.baseURL);
      const response = await fetch(`${this.baseURL}/${id}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching employee:', error);
      throw error;
    }
  }

  // Get employee by email
  async getEmployeeByEmail(email) {
    try {
      const response = await fetch(`${this.baseURL}/by-email/${encodeURIComponent(email)}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching employee by email:', error);
      throw error;
    }
  }

  // Get remarks for an employee (latest first). Requires Admin/HOD.
  async getEmployeeRemarks(employeeId) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/remarks`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching employee remarks:', error);
      throw error;
    }
  }

  // Add a remark for an employee. Requires Admin/HOD. text cannot be empty.
  async addEmployeeRemark(employeeId, text) {
    try {
      const trimmed = (text || '').trim();
      if (!trimmed) throw new Error('Remark text cannot be empty');
      const response = await fetch(`${this.baseURL}/${employeeId}/remarks`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ text: trimmed }),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error adding employee remark:', error);
      throw error;
    }
  }

  // Add an increment for an employee. Requires Admin/HOD.
  async addEmployeeIncrement(employeeId, incrementData) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/increments`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(incrementData),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error adding employee increment:', error);
      throw error;
    }
  }

  // Update an increment for an employee. Requires Admin/HOD.
  async updateEmployeeIncrement(employeeId, incrementId, incrementData) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/increments/${incrementId}`, {
        method: 'PUT',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(incrementData),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error updating employee increment:', error);
      throw error;
    }
  }

  // Delete an increment for an employee. Requires Admin/HOD.
  async deleteEmployeeIncrement(employeeId, incrementId) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/increments/${incrementId}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error deleting employee increment:', error);
      throw error;
    }
  }

  // Create new employee
  async createEmployee(employeeData) {
    try {
      console.log('Creating employee at:', this.baseURL);
      console.log('Employee data:', employeeData);

      const response = await fetch(this.baseURL, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(employeeData),
      });

      console.log('Response status:', response.status);
      console.log('Response headers:', response.headers);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      this.invalidateCache();
      return await response.json();
    } catch (error) {
      console.error('Error creating employee:', error);
      throw error;
    }
  }

  // // Update employee
  // async updateEmployee(id, employeeData) {
  //   try {
  //     const formData = new FormData();
  //     formData.append('data', JSON.stringify(employeeData));

  //     console.log('Updating employee at:', this.baseURL);
  //     console.log('Employee data:', employeeData);

  //     if (employeeData.profilePhotoFile) {
  //       formData.append('profilePhoto', employeeData.profilePhotoFile);
  //     }

  //     const response = await fetch(`${this.baseURL}/${id}`, {
  //       method: 'PUT',
  //       headers: {
  //         'Authorization': `Bearer ${localStorage.getItem('token')}`
  //       },
  //       body: formData,
  //     });

  //     if (!response.ok) {
  //       const errorData = await response.json();
  //       throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
  //     }

  //     return await response.json();
  //   } catch (error) {
  //     console.error('Error updating employee:', error);
  //     throw error;
  //   }
  // }


  // Update employee (supports both with and without file)
// EmployeeService.js - updateEmployee method
async updateEmployee(id, employeeData, profileImageFile = null) {
  try {
    const formData = new FormData();
    
    // Clean the data
    const dataToSend = { ...employeeData };
    
    // If profileImageFile is a base64 string, include it in the data payload
    if (typeof profileImageFile === 'string' && profileImageFile.startsWith('data:')) {
      dataToSend.profilePhoto = profileImageFile;
      profileImageFile = null;
    }
    
    // Make sure assignedProjects is an array
    if (dataToSend.assignedProjects) {
      if (!Array.isArray(dataToSend.assignedProjects)) {
        dataToSend.assignedProjects = [dataToSend.assignedProjects];
      }
      // Remove any null/undefined values
      dataToSend.assignedProjects = dataToSend.assignedProjects.filter(Boolean);
    }
    
    formData.append('data', JSON.stringify(dataToSend));

    if (profileImageFile) {
      console.log('📤 Adding profile image:', profileImageFile.name);
      formData.append('profilePhoto', profileImageFile);
    }

    const response = await fetch(`${this.baseURL}/${id}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: formData,
    });

    console.log('📥 Response status:', response.status);
    
    let responseData;
    try {
      responseData = await response.json();
    } catch (jsonError) {
      const text = await response.text();
      console.error('Failed to parse JSON:', text.substring(0, 200));
      throw new Error(`Server returned invalid JSON (${response.status}): ${text.substring(0, 100)}`);
    }

    if (!response.ok) {
      console.error('Server error response:', responseData);
      throw new Error(responseData.message || `HTTP error! status: ${response.status}`);
    }

    console.log('✅ Employee update successful:', responseData);
    this.invalidateCache();
    return responseData.employee || responseData;

  } catch (error) {
    console.error('❌ Error updating employee:', {
      message: error.message,
      stack: error.stack
    });
    throw error;
  }
}

// Remove or keep updateEmployeeWithFile if needed elsewhere
// async updateEmployeeWithFile(id, employeeData, profileImageFile) {
//   return this.updateEmployee(id, employeeData, profileImageFile);
// }

  // Delete employee
  async deleteEmployee(id) {
    try {
      console.log(`[EmployeeService] Deleting employee ${id}...`);
      const response = await fetch(`${this.baseURL}/${id}`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
      });

      console.log(`[EmployeeService] Delete response status: ${response.status}`);

      if (!response.ok) {
        const text = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(text);
        } catch (e) {
          console.error(`[EmployeeService] Failed to parse error JSON. Body:`, text.substring(0, 200));
          errorData = { message: `HTTP error! status: ${response.status}. Response is not JSON.` };
        }
        console.error(`[EmployeeService] Delete failed:`, errorData);
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      this.invalidateCache();
      return await response.json();
    } catch (error) {
      console.error('Error deleting employee:', error);
      throw error;
    }
  }

  // Bulk delete employees
  async bulkDeleteEmployees(ids) {
    try {
      const response = await fetch(`${this.baseURL}/bulk-delete`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ ids }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      this.invalidateCache();
      return await response.json();
    } catch (error) {
      console.error('Error bulk deleting employees:', error);
      throw error;
    }
  }

  // Create employee with profile photo
  // async createEmployeeWithFile(employeeData, profileImage) {
  //   try {
  //     console.log('Creating employee with file at:', this.baseURL);
  //     console.log('Profile image:', profileImage);

  //     const token = localStorage.getItem("token");
  //     const formDataToSend = new FormData();

  //     // Append employee data as JSON string
  //     formDataToSend.append("data", JSON.stringify(employeeData));

  //     // Append profile image if provided
  //     if (profileImage) {
  //       console.log('Appending profile image:', profileImage.name, profileImage.type, profileImage.size);
  //       formDataToSend.append("profilePhoto", profileImage);
  //     }

  //     const response = await fetch(this.baseURL, {
  //       method: "POST",
  //       headers: {
  //         Authorization: `Bearer ${token}`
  //       },
  //       body: formDataToSend,
  //     });

  //     console.log('Response status:', response.status);

  //     if (!response.ok) {
  //       let errorMessage = "Failed to create employee with file";
  //       try {
  //         const errorData = await response.json();
  //         errorMessage = errorData.message || errorMessage;
  //       } catch (e) {
  //         errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
  //       }
  //       throw new Error(errorMessage);
  //     }

  //     return await response.json();
  //   } catch (error) {
  //     console.error('Error in createEmployeeWithFile:', error);
  //     throw error;
  //   }
  // }

  async createEmployeeWithFile(employeeData, profileImageFile = null) {
  try {
    const formData = new FormData();
    
    const dataToSend = { ...employeeData };
    delete dataToSend.profilePhotoFile;
    
    // If profileImageFile is a base64 string, include it in the data payload
    if (typeof profileImageFile === 'string' && profileImageFile.startsWith('data:')) {
      dataToSend.profilePhoto = profileImageFile;
      profileImageFile = null;
    }
    
    formData.append('data', JSON.stringify(dataToSend));

    if (profileImageFile) {
      formData.append('profilePhoto', profileImageFile);
    }

    const response = await fetch(`${this.baseURL}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: formData,
    });

    const responseData = await response.json();

    if (!response.ok) {
      // Handle duplicate email error specifically
      if (response.status === 400 && responseData.error?.includes('Duplicate')) {
        throw new Error(responseData.message || 'Duplicate entry found');
      }
      throw new Error(responseData.message || `HTTP error! status: ${response.status}`);
    }

    this.invalidateCache();
    return responseData;
  } catch (error) {
    console.error('Error creating employee:', error);
    throw error;
  }
}

  async importEmployeesFromExcel(file) {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${this.baseURL}/import`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: formData,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.message || `Import failed (${response.status})`);
    }
    this.invalidateCache();
    return data;
  }

  // Update employee with profile photo
  async updateEmployeeWithFile(id, employeeData, profileImage) {
    try {
      console.log('Updating employee with file at:', `${this.baseURL}/${id}`);
      console.log('Profile image for update:', profileImage);

      const token = localStorage.getItem("token");
      const formDataToSend = new FormData();

      // Append employee data as JSON string
      const dataToSend = { ...employeeData };
      if (typeof profileImage === 'string' && profileImage.startsWith('data:')) {
        dataToSend.profilePhoto = profileImage;
        profileImage = null;
      }
      formDataToSend.append("data", JSON.stringify(dataToSend));

      // Append profile image if provided
      if (profileImage) {
        console.log('Appending profile image for update:', profileImage.name, profileImage.type, profileImage.size);
        formDataToSend.append("profilePhoto", profileImage);
      }

      const response = await fetch(`${this.baseURL}/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`
        },
        body: formDataToSend,
      });

      console.log('Update response status:', response.status);

      if (!response.ok) {
        let errorMessage = "Failed to update employee with file";
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch (e) {
          errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      const body = await response.json();
      this.invalidateCache();
      return body.employee || body;
    } catch (error) {
      console.error('Error in updateEmployeeWithFile:', error);
      throw error;
    }
  }

  // Additional employee-specific methods
  async getEmployeesByDepartment(department) {
    try {
      const response = await fetch(`${this.baseURL}/department/${department}`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching employees by department:', error);
      throw error;
    }
  }

  async updateEmployeeAttendance(id, attendanceStatus) {
    try {
      const today = new Date().toISOString().split('T')[0];
      const response = await fetch(this.attendanceURL, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({
          employeeId: id,
          date: today,
          status: attendanceStatus
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return {
        ...data,
        employee: {
          _id: id,
          attendance: attendanceStatus
        }
      };
    } catch (error) {
      console.error('Error updating employee attendance:', error);
      throw error;
    }
  }

  /**
   * Authorized vacation status transitions (Onsite / On Vacation / Yet to Go / Returned).
   * Uses dedicated endpoint so Authorize User can update status without full employee write access.
   */
  async updateVacationStatus(employeeId, payload = {}) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/vacation-status`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }
      this.invalidateCache();
      const data = await response.json();
      return data?.employee || data;
    } catch (error) {
      console.error('Error updating vacation status:', error);
      throw error;
    }
  }

  /**
   * Early or extended return from vacation.
   * Updates leave end date, vacation status, return dates, attendance.
   */
  async markVacationReturn(employeeId, { returnDate, firstWorkingDay, leaveId } = {}) {
    try {
      const response = await fetch(`${this.baseURL}/${employeeId}/vacation-return`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ returnDate, firstWorkingDay, leaveId }),
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }
      this.invalidateCache();
      return await response.json();
    } catch (error) {
      console.error('Error marking vacation return:', error);
      throw error;
    }
  }

  async assignProjectToEmployee(id, projectName) {
    try {
      const response = await fetch(`${this.baseURL}/${id}/projects`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ project: projectName }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error assigning project to employee:', error);
      throw error;
    }
  }

  async removeProjectFromEmployee(id, projectName) {
    try {
      const response = await fetch(`${this.baseURL}/${id}/projects`, {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ project: projectName }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error removing project from employee:', error);
      throw error;
    }
  }
}

export default new EmployeeService();
